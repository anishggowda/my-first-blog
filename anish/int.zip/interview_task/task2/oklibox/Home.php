<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US" class=" -webkit-">

<head>

<meta name="description" content="LTE">
<title>LTE</title>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
		
    <link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
	<link rel="shortcut icon" href="assets/logo_green.png" />
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
	<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
</head>
    <style media="screen,projection,print,handheld,tv" data-href="/v2/css/reset.css">/*----------------------------------Reset-------------------------------------*/
html,body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,pre,
form,fieldset,input,textarea,p,blockquote,th,td{margin:0;padding:0}
table{border-collapse:collapse;border-spacing:0}
fieldset,img{border:0}
address,caption,cite,code,dfn,em,
strong,th,var{font-style:normal;font-weight:normal}
ol,ul{list-style:none}
caption,th{text-align:left}
h1,h2,h3,h4,h5,h6{font-size:100%;font-weight:normal}
q:before,q:after{content:""}
abbr,acronym{border:0}
:focus {
    outline: 0;
}</style>
    <style media="screen,projection,print,handheld,tv" data-href="/v2/css/main-2.12.min.css">
	/*----------------------------1-General Tags----------------------------------*/
@media only screen and (max-width: 360px) {



body {
	font-size: 62.5%;
	font-family: Verdana, arial;
	color: #3a3a3a;
	background: #f1f4f4;
}



}
      
        

       

</style>
  
  <body>
    <div class="wrapper">
      	<div class="header">
		<div>
			<ul id="navigation">
				<li style="height: 19px;font-size: 1em;line-height: 31px;color: rgb(255,255,255);font-family:;font-weight: bold">
        <a href="#">DVD RENTAL</a>
            </li>
          
            <li  style="font-size: 1em;line-height: 1em;color: rgb(93,208,115);font-family: Nunito">
              <a href="#" style="color: rgb(93,208,115);text-decoration: none;font-family: Nunito">Home</a>
            </li>
            <li  style="font-size: 16px;line-height: 24px;color: rgb(255,255,255);font-family: Nunito">
              <a href="#">DVD Rental</a>
            </li>
      <li  style="font-size: 1em;line-height: 24px;color: rgb(255,255,255);font-family: Nunito">
              <a href="#">Smart Package Delivery</a>
            </li>
            <li  style="font-size: 1em;line-height: 24px;color: rgb(255,255,255);font-family: Nunito ">
              <a href="#">About</a>
            </li>
      <li  style="font-size: 1em;line-height: 24px;color: rgb(255,255,255);font-family: Nunito;width: 165px;height: 40px;box-shadow: 0 0 40px rgba(37,37,37,0.45);background-color: #5dcf73;">
              <a href="#">CONTACT US</a>
            </li>
        </ul>
		</div>
		<div  style="width:50%;height:auto">
		<div style="margin-top:60px;float:right"><h2>WHO WE ARE?</h2>
		<div id="h_line"></div>
		<div style="font-size:16px">
      We strive to provide more convienient and <br>economical way for everyone to enjoy entertainment <br>as well as recive packages by offering an integrated <br>system which provides a turnkey solution in automated <br>package delivery and convenient managment of <br>entertainment media contents.<br>
      <br>We provide of the line DVD Kisok rental service <br>because CD-type contents,such as DVD,Blue-ray,and <br>games.
		</div>
		</div>
		</div>
    </div>

    
    
   

</body></html>